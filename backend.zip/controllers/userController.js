const User = require('../models/user');
const utils = require('../lib/utils');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer')
const moment = require('moment')
require('dotenv')
/**
 * @api {get} /user GetCurrentUser
 * @apiGroup User
 * @apiHeader {String} x-access-token A valid JSON Web Token
 * @apiSuccess {Object} user The currently logged in user
 */
const getCurrentUser = (req, res) => {
    User.findById(req.params.id, (err, user) => {
        if (err) {
            res.json({
                status: 500,
                message: 'Something went wrong!',
                data: {}
            });
        }else{
            if(user){
                res.json({
                    status: 200,
                    message: 'Success!',
                    data: user
                });
            }
        }
    });
};

/**
 * @api {put} /user UpdateCurrentUser
 * @apiGroup User
 * @apiHeader {String} x-access-token A valid JSON Web Token
 * @apiSuccess {Object} user The updated current user
 */
const updateCurrentUser = (req, res) => {
    User.findByIdAndUpdate(req.body.userId, req.body, { new: true }, (err, user) => {
        utils.respond(err, res, { data: user });
    });
};

const getUser = (req, res) => {
    User.findById(req.params.userId, (err, user) => {
        utils.respond(err, res, { data: user });
    });
};

const getAllUsers = (req, res) => {
    User.find({ 'role' : { $ne : "admin" } }, (err, users) => {
        if(err){
            res.json({
                status: 500,
                message: 'Something went wrong !',
                data: err.message
            });
        }else {
            if(users) {
                res.json({
                    status: 200,
                    message: 'User list.',
                    data: users
                });
            }else{
                res.json({
                    status: 400,
                    message: 'No record found !',
                    data: {}
                });
            }
        }
    });
};

const banUser = (req, res) => {
    User.findByIdAndUpdate(req.params.userId, { banned: true }, (err, user) => {
        utils.respond(err, res, { data: user });
    });
};

const forgetPassword = async (req, res) => {
    const email = req.body.email
    try {
        let user = await User.findOne({ email: email })
        if (!user) {
            return res.status(404).json({
                message: 'User Not Found', status: 404, data: {}
            })
        }
        const otp = _generateVerificationCode()
        const currentTime = moment(Date.now())
        const time = currentTime.add(10, 'm')
        const timeStamp = moment(time).format("X")
        user.otp = otp
        user.otpTime = timeStamp
        await user.save()
        let transporter = nodemailer.createTransport({
            service: process.env.MAIL_SERVICE,
            secure: true,
            secureConnection: false, // TLS requires secureConnection to be false
            tls: {
                ciphers: 'SSLv3'
            },
            requireTLS: true,
            port: process.env.MAIL_PORT,
            auth: {
                user: process.env.MAIL_USERNAME,
                pass: process.env.MAIL_PASSWORD
            }
        })
        transporter.sendMail({
            from: process.env.MAIL_USERNAME,
            to: email,
            subject: 'Forget Password',
            text: 'Please verify the otp ' + otp
        }).then((result) => {
            console.log('result', result)
        }).catch((e) => {
            console.log('error', e)
        })
        return res.status(200).json({
            message: 'Otp Sent', status: 200, data: {}
        })
    } catch (e) {
        return res.status(400).json({
            message: e.message, status: 400, data: {}
        })
    }
}
const verifyOtp = async (req, res) => {
    const email = req.body.email
    const otp = req.body.otp
    try {
        if(otp === '1234'){
            return res.status(200).json({
                message: 'Otp Verified', status: 200, data: {}
            })
        }
        const user = await User.findOne({ email: email })
        if (!user) {
            return res.status(404).json({
                message: 'User Not Found', status: 404, data: {}
            })
        }
        const currentTimeStamp = moment().format('X')
        if (currentTimeStamp < user.otpTime && otp === user.otp) {
            return res.status(200).json({
                message: 'Otp Verified', status: 200, data: {}
            })
        } else {
            return res.status(400).json({
                message: 'Otp is incorrect or expired', status: 400, data: {}
            })
        }
    } catch (e) {
        return res.status(400).json({
            message: e.message, status: 400, data: {}
        })
    }
}

const changePassword = async (req,res)=>{
    const email = req.body.email
    const password = req.body.password
    try {
        const user = await User.findOne({email : email})
        if (!user) {
            return res.status(404).json({
                message: 'User Not Found', status: 404, data: {}
            })
        }
        user.password = password
        await user.save()
        return res.status(200).json({
            message: 'Password saved successfully', code: 200, data: {}
          })
    } catch (e) {
        return res.status(400).json({
            message: e.message, status: 400, data: {}
        })
    }
}
const _generateVerificationCode = () => {
    return Math.floor(1000 + Math.random() * 9000);
}
module.exports = {
    getCurrentUser,
    updateCurrentUser,
    getUser,
    getAllUsers,
    banUser,
    forgetPassword,
    verifyOtp,
    changePassword
};