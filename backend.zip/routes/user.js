const userController = require('../controllers/userController');
const isAuthenticated = require('../middleware/isAuthenticated');
const { check, body, validationResult } = require('express-validator');
module.exports = app => {
    app.get('/get-all-user', (req, res) => {
        userController.getAllUsers(req, res);
    });

    app.get('/user-profile/:id', (req, res) => {
        userController.getCurrentUser(req, res);
    });

    app.put('/profile-update', isAuthenticated, (req, res) => {
        userController.updateCurrentUser(req, res);
    });
    app.post('/forget-password',[
        body('email').not().trim().isEmpty().withMessage('Email is required.').isEmail().withMessage('Please enter a valid email.'),
    ], (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                status: 400,
                message: errors.array()[0].msg,
                data: {}
            });
        }
        userController.forgetPassword(req, res);
    });
    app.post('/verify-otp',[
        body('otp').not().trim().isEmpty().withMessage('Otp is required')
    ],(req,res)=>{
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                status: 400,
                message: errors.array()[0].msg,
                data: {}
            });
        }
        userController.verifyOtp(req,res);
    })
    app.post('/change-password',[
        body('password').not().trim().isEmpty().withMessage('Password is required')
    ],(req,res)=>{
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                status: 400,
                message: errors.array()[0].msg,
                data: {}
            });
        }
        userController.changePassword(req,res);
    })
};