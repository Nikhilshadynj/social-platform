const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
    jwt.verify(req.headers['x-access-token'], 'secretkey', function(err, decoded) {
        if (err) {
            console.log(err);
            res.status(401).json({
                status: 401,
                message: 'Unauthorized user!'
            });
        } else {
            req.body.userId = decoded.userId;
            next();
        }
    });
}